this code is from https://github.com/bjorn/tiled/tree/master 
and git commit-id is 43b35d4db73335eedf0312ca5871f1f0a2b08bf1


please execute command `mvn clean install`

2019/8/6